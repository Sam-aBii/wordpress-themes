TinyMCE
-------

includes/builder/frontend-builder/assets/vendors/tinymce.min.js
includes/builder/frontend-builder/assets/vendors/tinymce-skin/

```text
Copyright (c) 2016 Ephox

Licensed under the GPLv2.1.

See /LICENSE.md for the full GPLv2 license.
```

